<table style="border-collapse:collapse;width:700px;margin:5px;font-family: 'Source Sans Pro','Helvetica Neue',Helvetica,Arial,sans-serif;" border="0">
    <tr>
        <td colspan="5" style="text-align:center;"><?php $logo =  $company['Logo']; ?>
            <img style="width: 400px;" src="<?php echo base_url($avatar_dir . '/'.$logo); ?>"  alt="logo"></td>
    </tr>
    <tr style="text-align:center;font-size:13px;font-family: Arial, Helvetica, serif;padding:10px 5px 10px 5px;">
        <td colspan="5"><?php echo $company['AddressLine01'] ?><?php echo $company['AddressLine02'] ?><?php echo $company['AddressLine03'] ?> | <?php echo $company['LanLineNo'] ?>, <?php echo $company['Fax'] ?> <?php echo $company['MobileNo'] ?></td>
    </tr>
    <tr style="text-align:center;font-size:13px;font-family: Arial, Helvetica, serif;background-color: #bfbebe;padding:10px 5px 10px 5px;">
        <td colspan="5" style="border-bottom:1px solid #6d6666;border-top:1px solid #6d6666;">Authorized Motor Valuers for Leasing and Finances (L.A.S.L/V/0016)</td>
    </tr>
    <tr style="text-align:center;font-size:14px;border-bottom: #000 solid 1px;padding-bottom:5px;">
        <td colspan="6">&nbsp;</td>
    </tr>
</table>