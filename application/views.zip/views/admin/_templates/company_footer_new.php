<table style="border-collapse:collapse;width:550px;margin:5px;font-family: 'Source Sans Pro','Helvetica Neue',Helvetica,Arial,sans-serif;" border="0">
    <tr style="text-align:left;font-size:35px;font-family: Arial, Helvetica, sans-serif;">
        <td >
<!--            --><?php //$logo =  $company['Logo']; ?>
<!--            <img style="width: 550px;" src="--><?php //echo base_url($avatar_dir . '/'.$logo); ?><!--"  alt="logo">-->
             <img style="width: 550px;" src="<?php echo base_url($avatar_dir . '/'.'footer_logo.png'); ?>"  alt="footer_logo">
        </td>


    </tr>

</table>