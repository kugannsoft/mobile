<table style="border-collapse:collapse;width:700px;margin:5px;font-family: 'Source Sans Pro','Helvetica Neue',Helvetica,Arial,sans-serif;position: fixed;bottom: 20px;" border="0">
    <tr>
        <td colspan="5" style="text-align:center;"><?php $footer_logo =  'footer.jpg'; ?>
            <img style="width: 700px;" src="<?php echo 'upload/avatar/'.$footer_logo; ?>"  alt="footer_logo"></td>
    </tr>
</table>